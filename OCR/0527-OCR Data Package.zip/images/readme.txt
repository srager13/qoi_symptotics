Due to size limitations, I had to remove the ./tif-x.y/ folders.  If they're re-created in the
images directory you can use the batch_convert.sh shell script to regenerate them.